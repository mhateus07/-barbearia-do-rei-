Seu Barbeiro é o sistema de gestão de barbearias e salões: agenda por profissional, clientes, comanda, Pix e caixa. A marca existe para uma coisa: o dono do salão confiar o horário dos clientes e o dinheiro do caixa a ela. Tudo aqui serve a isso. Calma, precisa e com cara de ofício, nunca de "startup".

Assinatura: **Cadeira cheia, agenda em dia.**

## A ideia da marca: hora do corte

O símbolo é um relógio cujos ponteiros são uma tesoura aberta em 10h10, a posição que os relojoeiros usam nas vitrines. Os dois aros da tesoura ficam dentro do mostrador; o pino central é o único ponto vermelho. Lido de longe, lembra também um bigode.

- O mostrador diz **agenda e pontualidade**.
- A tesoura diz **ofício**: serve para barbearia e para salão, sem cair na caveira, no brasão ou na coroa dourada que todo concorrente usa.
- O pino vermelho vem do poste de barbeiro. É a única cor quente da marca e por isso chama o olho.

O nome se escreve **Seu Barbeiro** em texto corrido. No logotipo ele aparece em minúsculas, `seu barbeiro`, em Archivo largo e pesado, como letreiro de fachada.

## Logo

Arquivos no grupo **Logos**. Use sempre os arquivos; não redesenhe nem digite o logotipo numa fonte.

- `seu-barbeiro-horizontal.svg`: versão principal. Topo de site, cabeçalho do painel, assinatura de e-mail.
- `seu-barbeiro-horizontal-negativo.svg`: a mesma sobre `marca-navalha` ou foto escura.
- `seu-barbeiro-vertical.svg`: espaços quadrados (perfil de rede social impresso, adesivo de vitrine).
- `seu-barbeiro-simbolo.svg` e `-negativo`: quando o nome já está escrito ao lado ou o espaço é menor que 120px de largura.
- `seu-barbeiro-icone-app.svg`: ícone do app, favicon, foto de perfil no Instagram e WhatsApp.
- `seu-barbeiro-logotipo.svg`: só o nome, para rodapés e créditos ("feito com seu barbeiro").

Regras:

- Área de proteção: metade da altura do símbolo em volta de todo o logo. Nada entra ali.
- Tamanho mínimo: símbolo com 16px (favicon); logo horizontal com 120px de largura.
- O pino é sempre `marca-poste`, nas duas versões. O resto do logo é uma tinta só: `marca-navalha` no claro, `marca-espuma` no escuro.
- Não gire, não aplique sombra, contorno, degradê ou dourado. Não troque as cores do pino e do mostrador. Não ponha o logo sobre foto movimentada sem a faixa `marca-navalha` atrás.

## Cor

A marca é **azul-marinho com um ponto de vermelho**. Azul passa seriedade e dinheiro bem cuidado; o vermelho é do poste de barbearia e aparece pouco.

| Cor | Token | Uso |
| --- | --- | --- |
| Azul Navalha `#15233F` | `marca-navalha` | 60% de qualquer peça. Fundo de ícone, faixas, botões principais. |
| Espuma `#F5F4F0` | `marca-espuma` | Papel, fundo claro de peças, logo negativo. |
| Azul Toalha `#C9DAEE` | `marca-toalha` | Bloco de apoio, fundo de destaque suave. |
| Vermelho Poste `#D8462A` | `marca-poste` | No máximo 5% da peça: o pino, um sublinhado, um número em destaque. |

Na interface, use os tokens de papel, não os de marca:

- Fundo `surface`; cartões e agenda em `surface-raised`; divisórias `line`; borda de campos `line-strong`.
- Texto `ink`; texto de apoio `ink-muted`.
- Botão principal `brand` com texto `on-brand`. Só um botão principal por tela.
- `accent` marca a linha da hora atual na agenda, contadores e um link de destaque. **Nunca** é botão principal e **nunca** indica erro.
- Estados (`success`, `warning`, `danger`) aparecem sempre com a palavra e um ícone: "Pago", "Aguardando Pix", "Faltou". A cor sozinha nunca carrega a informação.
- No tema escuro, `brand` vira azul claro e o texto sobre ele fica escuro (`on-brand`). Não use branco sobre `brand` no escuro.

Todas as combinações de texto acima passam 4.5:1 nos dois temas. `marca-poste` sobre branco fica em 4.3:1: use só em formas e em texto de 24px ou mais.

## Tipografia

Três famílias, todas do Google Fonts:

- **Archivo** (`display`), largura 112, peso 700–800: títulos, manchetes, números grandes de painel. Letra larga de letreiro, dá presença sem enfeite.
- **Hanken Grotesk** (`sans`): todo o texto de interface e de leitura.
- **IBM Plex Mono** (`mono`): horários e valores (`hora`). Os números ficam alinhados em coluna, como num livro-caixa.

Escala fixa: `display-xl`, `display-l`, `title`, `subtitle`, `body`, `body-sm`, `label`, `hora`. Não crie tamanhos fora dela. Títulos em frase normal ("Agenda de hoje"), nunca Tudo Em Maiúscula Inicial. Caixa alta só no `label`, com espaçamento.

Dinheiro sempre `R$ 45,00` (espaço depois do R$, vírgula decimal). Hora sempre `09:30`, intervalo `09:30 – 10:15`. Data `26/09` ou `sexta, 26 de setembro`.

## Forma e espaço

- Espaçamento em passos de 4: `space-1` a `space-12`. Margem lateral mínima de `space-4` no celular.
- Cantos: `radius-md` em botões e cartões; `radius-pill` só em filtros e chips de profissional.
- Cartões parados têm borda `line` e nenhuma sombra. `shadow-card` só para o que flutua (cartão sendo arrastado, modal).
- Sem cartões com faixa colorida na lateral. O status vai no selo, não numa borda.

## Ícones

Traço de 1,75px, cantos arredondados, grade de 24px (Lucide é a referência). Ícone sempre acompanha texto em botões e menus; sozinho, só com rótulo acessível. Sem emoji na interface.

## Imagem

Fotos reais de barbearias e salões brasileiros, luz natural, mãos trabalhando, cadeira, espelho, ferramentas. Nada de banco de imagens com modelo posando, nada de render 3D, nada de arte gerada por IA. Quando não houver foto, use os blocos de cor e o mostrador; não invente ilustração.

## Como a marca fala

Fala como um dono de barbearia que organiza bem o próprio negócio: direto, educado, com números. Trata por **você**. Sem gíria forçada ("brother", "mano"), sem inglês de startup ("dashboard", "onboarding", "insights") quando existe palavra em português: painel, primeiros passos, resultados.

- Diga o que acontece, com número: "Lembrete enviado para 14 clientes de amanhã." Não: "Seus clientes foram notificados com sucesso!"
- Botões dizem a ação: "Agendar", "Receber no Pix", "Fechar caixa". Nunca "OK" ou "Enviar".
- Erro explica e resolve: "Esse horário já está com o Rafael. Escolha 10:15 ou outro profissional."
- Confiança se mostra, não se promete: "Cada salão tem o próprio banco de dados." em vez de "Segurança de ponta".
- Sem ponto de exclamação na interface. No máximo um em marketing.

Exemplo de mensagem para o cliente final (WhatsApp):

> Oi, Mariana. Seu horário na Barbearia Aurora está marcado para amanhã, sexta, às 09:30, com a Camila (Corte e finalização). Para remarcar, responda esta mensagem.

## Aplicações principais

- **Ícone do app e favicon**: `seu-barbeiro-icone-app.svg`.
- **Painel**: barra lateral em `marca-navalha` com o logo negativo; conteúdo em `surface`.
- **Página pública de agendamento**: o logo do salão cliente vem primeiro; o nosso aparece só no rodapé, com `seu-barbeiro-logotipo.svg` em `ink-muted`.
- **Instagram**: posts em `marca-espuma` ou `marca-navalha`, título em Archivo, um único detalhe em `marca-poste`.
